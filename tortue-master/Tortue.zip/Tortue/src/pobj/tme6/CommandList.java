package pobj.tme6;

import java.util.ArrayList;
import java.util.List;

public class CommandList implements ICommand{
	private List<ICommand> list;
	
	public CommandList() {
		list= new ArrayList<ICommand>();
	}
	
	public void addCommand(ICommand command) {
		list.add(command);
	}
 
	@Override
	public void execute(IColorTurtle turtle) {
		for(ICommand command: list)
			command.execute(turtle);
	}
}
