package pobj.tme6;

import javafx.scene.paint.Color;

public class ColorTurtleAdapter implements IColorTurtle{

	private ITurtle iturtle;
	private Color color;
	
	public ColorTurtleAdapter(ITurtle iturtle) {
		this.iturtle=iturtle;
		color=Color.BLACK;
	}
	
	@Override
	public void move(int length) {
		iturtle.move(length);
	}

	@Override
	public void turn(int angle) {
		iturtle.turn(angle);
	}

	@Override
	public void up() {
		iturtle.up();
		
	}

	@Override
	public void down() {
		iturtle.down();
		
	}

	@Override
	public void setColor(Color color) {
		this.color=color;
	}

	
}
